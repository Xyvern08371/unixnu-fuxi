/*
 * Intel ACPI Component Architecture
 * AML/ASL+ Disassembler version 20230628 (32-bit version)
 * Copyright (c) 2000 - 2023 Intel Corporation
 * 
 * Disassembly of APIC.UniCore.aml
 *
 * ACPI Data Table [APIC]
 *
 * Format: [HexOffset DecimalOffset ByteLength]  FieldName : FieldValue (in hex)
 */

[000h 0000 004h]                   Signature : "APIC"    [Multiple APIC Description Table (MADT)]
[004h 0004 004h]                Table Length : 000002E4
[008h 0008 001h]                    Revision : 05
[009h 0009 001h]                    Checksum : 0A
[00Ah 0010 006h]                      Oem ID : "MTK   "
[010h 0016 008h]                Oem Table ID : "MEDIATEK"
[018h 0024 004h]                Oem Revision : 00006768
[01Ch 0028 004h]             Asl Compiler ID : "INTL"
[020h 0032 004h]       Asl Compiler Revision : 20240827

[024h 0036 004h]          Local Apic Address : 00000000
[028h 0040 004h]       Flags (decoded below) : 00000000
                         PC-AT Compatibility : 0

[02Ch 0044 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[02Dh 0045 001h]                      Length : 52
[02Eh 0046 002h]                    Reserved : 0000
[030h 0048 004h]        CPU Interface Number : 00000000
[034h 0052 004h]               Processor UID : 00000000
[038h 0056 004h]       Flags (decoded below) : 00000001
                           Processor Enabled : 1
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[03Ch 0060 004h]    Parking Protocol Version : 00000000
[040h 0064 004h]       Performance Interrupt : 00000017
[044h 0068 008h]              Parked Address : 0000000000000000
[04Ch 0076 008h]                Base Address : 0000000000000000
[054h 0084 008h]    Virtual GIC Base Address : 0000000000000000
[05Ch 0092 008h] Hypervisor GIC Base Address : 0000000000000000
[064h 0100 004h]       Virtual GIC Interrupt : 00000019
[068h 0104 008h]  Redistributor Base Address : 0000000000000000
[070h 0112 008h]                   ARM MPIDR : 0000000000000000
[078h 0120 001h]            Efficiency Class : 00
[079h 0121 001h]                    Reserved : 00
[07Ah 0122 002h]      SPE Overflow Interrupt : 0000
[07Ch 0124 002h]              TRBE Interrupt : 500B

[07Eh 0126 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[07Fh 0127 001h]                      Length : 52
[080h 0128 002h]                    Reserved : 0000
[082h 0130 004h]        CPU Interface Number : 00000001
[086h 0134 004h]               Processor UID : 00000001
[08Ah 0138 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[08Eh 0142 004h]    Parking Protocol Version : 00000000
[092h 0146 004h]       Performance Interrupt : 00000017
[096h 0150 008h]              Parked Address : 0000000000000000
[09Eh 0158 008h]                Base Address : 0000000000000000
[0A6h 0166 008h]    Virtual GIC Base Address : 0000000000000000
[0AEh 0174 008h] Hypervisor GIC Base Address : 0000000000000000
[0B6h 0182 004h]       Virtual GIC Interrupt : 00000019
[0BAh 0186 008h]  Redistributor Base Address : 0000000000000000
[0C2h 0194 008h]                   ARM MPIDR : 0000000000000100
[0CAh 0202 001h]            Efficiency Class : 00
[0CBh 0203 001h]                    Reserved : 00
[0CCh 0204 002h]      SPE Overflow Interrupt : 0000
[0CEh 0206 002h]              TRBE Interrupt : 500B

[0D0h 0208 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[0D1h 0209 001h]                      Length : 52
[0D2h 0210 002h]                    Reserved : 0000
[0D4h 0212 004h]        CPU Interface Number : 00000002
[0D8h 0216 004h]               Processor UID : 00000002
[0DCh 0220 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[0E0h 0224 004h]    Parking Protocol Version : 00000000
[0E4h 0228 004h]       Performance Interrupt : 00000017
[0E8h 0232 008h]              Parked Address : 0000000000000000
[0F0h 0240 008h]                Base Address : 0000000000000000
[0F8h 0248 008h]    Virtual GIC Base Address : 0000000000000000
[100h 0256 008h] Hypervisor GIC Base Address : 0000000000000000
[108h 0264 004h]       Virtual GIC Interrupt : 00000019
[10Ch 0268 008h]  Redistributor Base Address : 0000000000000000
[114h 0276 008h]                   ARM MPIDR : 0000000000000200
[11Ch 0284 001h]            Efficiency Class : 00
[11Dh 0285 001h]                    Reserved : 00
[11Eh 0286 002h]      SPE Overflow Interrupt : 0000
[120h 0288 002h]              TRBE Interrupt : 500B

[122h 0290 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[123h 0291 001h]                      Length : 52
[124h 0292 002h]                    Reserved : 0000
[126h 0294 004h]        CPU Interface Number : 00000003
[12Ah 0298 004h]               Processor UID : 00000003
[12Eh 0302 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[132h 0306 004h]    Parking Protocol Version : 00000000
[136h 0310 004h]       Performance Interrupt : 00000017
[13Ah 0314 008h]              Parked Address : 0000000000000000
[142h 0322 008h]                Base Address : 0000000000000000
[14Ah 0330 008h]    Virtual GIC Base Address : 0000000000000000
[152h 0338 008h] Hypervisor GIC Base Address : 0000000000000000
[15Ah 0346 004h]       Virtual GIC Interrupt : 00000019
[15Eh 0350 008h]  Redistributor Base Address : 0000000000000000
[166h 0358 008h]                   ARM MPIDR : 0000000000000300
[16Eh 0366 001h]            Efficiency Class : 00
[16Fh 0367 001h]                    Reserved : 00
[170h 0368 002h]      SPE Overflow Interrupt : 0000
[172h 0370 002h]              TRBE Interrupt : 500B

[174h 0372 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[175h 0373 001h]                      Length : 52
[176h 0374 002h]                    Reserved : 0000
[178h 0376 004h]        CPU Interface Number : 00000004
[17Ch 0380 004h]               Processor UID : 00000004
[180h 0384 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[184h 0388 004h]    Parking Protocol Version : 00000000
[188h 0392 004h]       Performance Interrupt : 00000017
[18Ch 0396 008h]              Parked Address : 0000000000000000
[194h 0404 008h]                Base Address : 0000000000000000
[19Ch 0412 008h]    Virtual GIC Base Address : 0000000000000000
[1A4h 0420 008h] Hypervisor GIC Base Address : 0000000000000000
[1ACh 0428 004h]       Virtual GIC Interrupt : 00000019
[1B0h 0432 008h]  Redistributor Base Address : 0000000000000000
[1B8h 0440 008h]                   ARM MPIDR : 0000000000000400
[1C0h 0448 001h]            Efficiency Class : 01
[1C1h 0449 001h]                    Reserved : 00
[1C2h 0450 002h]      SPE Overflow Interrupt : 0000
[1C4h 0452 002h]              TRBE Interrupt : 500B

[1C6h 0454 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[1C7h 0455 001h]                      Length : 52
[1C8h 0456 002h]                    Reserved : 0000
[1CAh 0458 004h]        CPU Interface Number : 00000005
[1CEh 0462 004h]               Processor UID : 00000005
[1D2h 0466 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[1D6h 0470 004h]    Parking Protocol Version : 00000000
[1DAh 0474 004h]       Performance Interrupt : 00000017
[1DEh 0478 008h]              Parked Address : 0000000000000000
[1E6h 0486 008h]                Base Address : 0000000000000000
[1EEh 0494 008h]    Virtual GIC Base Address : 0000000000000000
[1F6h 0502 008h] Hypervisor GIC Base Address : 0000000000000000
[1FEh 0510 004h]       Virtual GIC Interrupt : 00000019
[202h 0514 008h]  Redistributor Base Address : 0000000000000000
[20Ah 0522 008h]                   ARM MPIDR : 0000000000000500
[212h 0530 001h]            Efficiency Class : 01
[213h 0531 001h]                    Reserved : 00
[214h 0532 002h]      SPE Overflow Interrupt : 0000
[216h 0534 002h]              TRBE Interrupt : 500B

[218h 0536 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[219h 0537 001h]                      Length : 52
[21Ah 0538 002h]                    Reserved : 0000
[21Ch 0540 004h]        CPU Interface Number : 00000006
[220h 0544 004h]               Processor UID : 00000006
[224h 0548 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[228h 0552 004h]    Parking Protocol Version : 00000000
[22Ch 0556 004h]       Performance Interrupt : 00000017
[230h 0560 008h]              Parked Address : 0000000000000000
[238h 0568 008h]                Base Address : 0000000000000000
[240h 0576 008h]    Virtual GIC Base Address : 0000000000000000
[248h 0584 008h] Hypervisor GIC Base Address : 0000000000000000
[250h 0592 004h]       Virtual GIC Interrupt : 00000019
[254h 0596 008h]  Redistributor Base Address : 0000000000000000
[25Ch 0604 008h]                   ARM MPIDR : 0000000000000600
[264h 0612 001h]            Efficiency Class : 01
[265h 0613 001h]                    Reserved : 00
[266h 0614 002h]      SPE Overflow Interrupt : 0000
[268h 0616 002h]              TRBE Interrupt : 500B

[26Ah 0618 001h]               Subtable Type : 0B [Generic Interrupt Controller]
[26Bh 0619 001h]                      Length : 52
[26Ch 0620 002h]                    Reserved : 0000
[26Eh 0622 004h]        CPU Interface Number : 00000007
[272h 0626 004h]               Processor UID : 00000007
[276h 0630 004h]       Flags (decoded below) : 00000000
                           Processor Enabled : 0
          Performance Interrupt Trigger Mode : 0
          Virtual GIC Interrupt Trigger Mode : 0
[27Ah 0634 004h]    Parking Protocol Version : 00000000
[27Eh 0638 004h]       Performance Interrupt : 00000017
[282h 0642 008h]              Parked Address : 0000000000000000
[28Ah 0650 008h]                Base Address : 0000000000000000
[292h 0658 008h]    Virtual GIC Base Address : 0000000000000000
[29Ah 0666 008h] Hypervisor GIC Base Address : 0000000000000000
[2A2h 0674 004h]       Virtual GIC Interrupt : 00000019
[2A6h 0678 008h]  Redistributor Base Address : 0000000000000000
[2AEh 0686 008h]                   ARM MPIDR : 0000000000000700
[2B6h 0694 001h]            Efficiency Class : 02
[2B7h 0695 001h]                    Reserved : 00
[2B8h 0696 002h]      SPE Overflow Interrupt : 0000
[2BAh 0698 002h]              TRBE Interrupt : 190C

[2BCh 0700 001h]               Subtable Type : 0C [Generic Interrupt Distributor]
[2BDh 0701 001h]                      Length : 18
[2BEh 0702 002h]                    Reserved : 0000
[2C0h 0704 004h]       Local GIC Hardware ID : 00000000
[2C4h 0708 008h]                Base Address : 000000000C000000
[2CCh 0716 004h]              Interrupt Base : 00000000
[2D0h 0720 001h]                     Version : 03
[2D1h 0721 003h]                    Reserved : 000000

[2D4h 0724 001h]               Subtable Type : 0E [Generic Interrupt Redistributor]
[2D5h 0725 001h]                      Length : 10
[2D7h 0727 002h]                    Reserved : 0000
[2D8h 0728 008h]                Base Address : 000000000C040000
[2E0h 0736 004h]                      Length : 00200000

Raw Table Data: Length 740 (0x2E4)

    0000: 41 50 49 43 E4 02 00 00 05 0A 4D 54 4B 20 20 20  // APIC......MTK   
    0010: 4D 45 44 49 41 54 45 4B 68 67 00 00 49 4E 54 4C  // MEDIATEKhg..INTL
    0020: 27 08 24 20 00 00 00 00 00 00 00 00 0B 52 00 00  // '.$ .........R..
    0030: 00 00 00 00 00 00 00 00 01 00 00 00 00 00 00 00  // ................
    0040: 17 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0050: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0060: 00 00 00 00 19 00 00 00 00 00 00 00 00 00 00 00  // ................
    0070: 00 00 00 00 00 00 00 00 00 00 00 00 0B 50 0B 52  // .............P.R
    0080: 00 00 01 00 00 00 01 00 00 00 00 00 00 00 00 00  // ................
    0090: 00 00 17 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    00A0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    00B0: 00 00 00 00 00 00 19 00 00 00 00 00 00 00 00 00  // ................
    00C0: 00 00 00 01 00 00 00 00 00 00 00 00 00 00 0B 50  // ...............P
    00D0: 0B 52 00 00 02 00 00 00 02 00 00 00 00 00 00 00  // .R..............
    00E0: 00 00 00 00 17 00 00 00 00 00 00 00 00 00 00 00  // ................
    00F0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0100: 00 00 00 00 00 00 00 00 19 00 00 00 00 00 00 00  // ................
    0110: 00 00 00 00 00 02 00 00 00 00 00 00 00 00 00 00  // ................
    0120: 0B 50 0B 52 00 00 03 00 00 00 03 00 00 00 00 00  // .P.R............
    0130: 00 00 00 00 00 00 17 00 00 00 00 00 00 00 00 00  // ................
    0140: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0150: 00 00 00 00 00 00 00 00 00 00 19 00 00 00 00 00  // ................
    0160: 00 00 00 00 00 00 00 03 00 00 00 00 00 00 00 00  // ................
    0170: 00 00 0B 50 0B 52 00 00 04 00 00 00 04 00 00 00  // ...P.R..........
    0180: 00 00 00 00 00 00 00 00 17 00 00 00 00 00 00 00  // ................
    0190: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    01A0: 00 00 00 00 00 00 00 00 00 00 00 00 19 00 00 00  // ................
    01B0: 00 00 00 00 00 00 00 00 00 04 00 00 00 00 00 00  // ................
    01C0: 01 00 00 00 0B 50 0B 52 00 00 05 00 00 00 05 00  // .....P.R........
    01D0: 00 00 00 00 00 00 00 00 00 00 17 00 00 00 00 00  // ................
    01E0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    01F0: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 19 00  // ................
    0200: 00 00 00 00 00 00 00 00 00 00 00 05 00 00 00 00  // ................
    0210: 00 00 01 00 00 00 0B 50 0B 52 00 00 06 00 00 00  // .......P.R......
    0220: 06 00 00 00 00 00 00 00 00 00 00 00 17 00 00 00  // ................
    0230: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0240: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0250: 19 00 00 00 00 00 00 00 00 00 00 00 00 06 00 00  // ................
    0260: 00 00 00 00 01 00 00 00 0B 50 0B 52 00 00 07 00  // .........P.R....
    0270: 00 00 07 00 00 00 00 00 00 00 00 00 00 00 17 00  // ................
    0280: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    0290: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  // ................
    02A0: 00 00 19 00 00 00 00 00 00 00 00 00 00 00 00 07  // ................
    02B0: 00 00 00 00 00 00 02 00 00 00 0C 19 0C 18 00 00  // ................
    02C0: 00 00 00 00 00 00 00 0C 00 00 00 00 00 00 00 00  // ................
    02D0: 03 00 00 00 0E 10 00 00 00 00 04 0C 00 00 00 00  // ................
    02E0: 00 00 20 00                                      // .. .
