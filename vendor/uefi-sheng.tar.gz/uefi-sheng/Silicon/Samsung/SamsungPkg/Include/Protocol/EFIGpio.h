#ifndef _EFI_GPIO_H_
#define _EFI_GPIO_H_

#include <Device/Gpio.h>

/**
  This Function gets the current State of the Specified GPIO Pin.

  @param[in]  BankId                       - The GPIO Bank ID of the GPIO Pin.
  @param[in]  BankNumber                   - The GPIO Bank Number of the GPIO Pin.
  @param[in]  Pin                          - The GPIO Pin.
  @param[out] State                        - The current State.

  @return EFI_SUCCESS                      - Successfully got the current State of the Specified GPIO Pin.
  @return EFI_INVALID_PARAMETER            - The "BankId" Parameter is Invalid.
  @return EFI_INVALID_PARAMETER            - The "Pin" Parameter is larger than 7.
  @return EFI_NOT_FOUND                    - The Specified GPIO Bank does not Exist.
  @return EFI_NOT_READY                    - The GPIO Controller Memory isn't Mapped yet.
**/
typedef
EFI_STATUS
(EFIAPI *EFI_GPIO_GET_STATE) (
  IN  EFI_GPIO_BANK_ID  BankId,
  IN  UINT8             BankNumber,
  IN  UINT8             Pin,
  OUT BOOLEAN          *State
  );

/**
  This Function Enables/Disables the Specified GPIO Pin.

  @param[in] BankId                        - The GPIO Bank ID of the GPIO Pin.
  @param[in] BankNumber                    - The GPIO Bank Number of the GPIO Pin.
  @param[in] Pin                           - The GPIO Pin.
  @param[in] Enable                        - The new State.

  @return EFI_SUCCESS                      - Successfully Enabled/Disabled the Specified GPIO Pin.
  @return EFI_INVALID_PARAMETER            - The "BankId" Parameter is Invalid.
  @return EFI_INVALID_PARAMETER            - The "Pin" Parameter is larger than 7.
  @return EFI_NOT_FOUND                    - The Specified GPIO Bank does not Exist.
  @return EFI_NOT_READY                    - The GPIO Controller Memory isn't Mapped yet.
**/
typedef
EFI_STATUS
(EFIAPI *EFI_GPIO_SET_STATE)(
  IN EFI_GPIO_BANK_ID  BankId,
  IN UINT8             BankNumber,
  IN UINT8             Pin,
  IN BOOLEAN          *Enable
  );

/**
  This Function sets the Specified Function of the Specified GPIO Pin.

  @param[in] BankId                        - The GPIO Bank ID of the GPIO Pin.
  @param[in] BankNumber                    - The GPIO Bank Number of the GPIO Pin.
  @param[in] Pin                           - The GPIO Pin.
  @param[in] Function                      - The Function.

  @return EFI_SUCCESS                      - Successfully set the Function of the Specified GPIO Pin.
  @return EFI_INVALID_PARAMETER            - The "BankId" Parameter is Invalid.
  @return EFI_INVALID_PARAMETER            - The "Pin" Parameter is larger than 7.
  @return EFI_INVALID_PARAMETER            - The "Function" Parameter is Invalid.
  @return EFI_NOT_FOUND                    - The Specified GPIO Bank does not Exist.
  @return EFI_NOT_READY                    - The GPIO Controller Memory isn't Mapped yet.
**/
typedef
EFI_STATUS
(EFIAPI *EFI_GPIO_SET_FUNCTION) (
  IN EFI_GPIO_BANK_ID  BankId,
  IN UINT8             BankNumber,
  IN UINT8             Pin,
  IN EFI_GPIO_FUNCTION Function
  );

/**
  This Function sets the Specified Pull Mode of the Specified GPIO Pin.

  @param[in] BankId                        - The GPIO Bank ID of the GPIO Pin.
  @param[in] BankNumber                    - The GPIO Bank Number of the GPIO Pin.
  @param[in] Pin                           - The GPIO Pin.
  @param[in] Pull                          - The new Pull Mode.

  @return EFI_SUCCESS                      - Successfully set the new Direction of the Specified GPIO Pin.
  @return EFI_INVALID_PARAMETER            - The "BankId" Parameter is Invalid.
  @return EFI_INVALID_PARAMETER            - The "Pin" Parameter is larger than 7.
  @return EFI_INVALID_PARAMETER            - The "Pull" Parameter is Invalid.
  @return EFI_NOT_FOUND                    - The Specified GPIO Bank does not Exist.
  @return EFI_NOT_READY                    - The GPIO Controller Memory isn't Mapped yet.
**/
typedef
EFI_STATUS
(EFIAPI *EFI_GPIO_SET_PULL) (
  IN EFI_GPIO_BANK_ID   BankId,
  IN UINT8              BankNumber,
  IN UINT8              Pin,
  IN EFI_GPIO_PULL_MODE Pull
  );

/**
  This Function sets the Specified Drive Strength of the Specified GPIO Pin.

  @param[in] BankId                        - The GPIO Bank ID of the GPIO Pin.
  @param[in] BankNumber                    - The GPIO Bank Number of the GPIO Pin.
  @param[in] Pin                           - The GPIO Pin.
  @param[in] Drive                         - The new Drive Strength.

  @return EFI_SUCCESS                      - Successfully set the new Drive Strength of the Specified GPIO Pin.
  @return EFI_INVALID_PARAMETER            - The "BankId" Parameter is Invalid.
  @return EFI_INVALID_PARAMETER            - The "Pin" Parameter is larger than 7.
  @return EFI_INVALID_PARAMETER            - The "Drive" Parameter is Invalid.
  @return EFI_NOT_FOUND                    - The Specified GPIO Bank does not Exist.
  @return EFI_NOT_READY                    - The GPIO Controller Memory isn't Mapped yet.
**/
typedef
EFI_STATUS
(EFIAPI *EFI_GPIO_SET_DRIVE) (
  IN EFI_GPIO_BANK_ID         BankId,
  IN UINT8                    BankNumber,
  IN UINT8                    Pin,
  IN EFI_GPIO_DRIVE_STRENGTH  Drive
  );

//
// Define Protocol
//
typedef struct {
  EFI_GPIO_GET_STATE    GetState;
  EFI_GPIO_SET_STATE    SetState;
  EFI_GPIO_SET_FUNCTION SetFunction;
  EFI_GPIO_SET_PULL     SetPull;
  EFI_GPIO_SET_DRIVE    SetDrive;
} EFI_GPIO_PROTOCOL;

#endif /* _EFI_GPIO_H_ */
