/*
 * Copyright (c) 2022 Apple Inc. All rights reserved.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_START@
 *
 * This file contains Original Code and/or Modifications of Original Code
 * as defined in and that are subject to the Apple Public Source License
 * Version 2.0 (the 'License'). You may not use this file except in
 * compliance with the License. The rights granted to you under the License
 * may not be used to create, or enable the creation or redistribution of,
 * unlawful or unlicensed copies of an Apple operating system, or to
 * circumvent, violate, or enable the circumvention or violation of, any
 * terms of an Apple operating system software license agreement.
 *
 * Please obtain a copy of the License at
 * http://www.opensource.apple.com/apsl/ and read it before using this file.
 *
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, QUIET ENJOYMENT OR NON-INFRINGEMENT.
 * Please see the License for the specific language governing rights and
 * limitations under the License.
 *
 * @APPLE_OSREFERENCE_LICENSE_HEADER_END@
 */

#ifndef _MACH_EXCLAVES_H
#define _MACH_EXCLAVES_H


#include <os/base.h>
#include <mach/mach_types.h>
#include <mach/mach_param.h>


__BEGIN_DECLS

typedef uint64_t exclaves_id_t;
typedef uint64_t exclaves_tag_t;
typedef uint64_t exclaves_error_t;

/*!
 * @enum exclaves_sensor_status_t
 *
 * @brief
 * The status of an exclaves sensor.
 *
 * Indicates if data from this sensor can currently be accessed.
 * If the data cannot be accessed, exclaves_sensor_start() must be
 * called (with an accompanying exclaves_sensor_stop()).
 *
 * If the data cannot be accessed, then reading sensor data will
 * only result in 0s.
 */
OS_ENUM(exclaves_sensor_status, uint32_t,
    EXCLAVES_SENSOR_STATUS_ALLOWED = 1,
    EXCLAVES_SENSOR_STATUS_DENIED = 2,
    EXCLAVES_SENSOR_STATUS_CONTROL = 3,
    );

OS_CLOSED_OPTIONS(exclaves_buffer_perm, uint32_t,
    EXCLAVES_BUFFER_PERM_READ = 1,
    EXCLAVES_BUFFER_PERM_WRITE = 2,
    );

OS_ENUM(exclaves_boot_stage, uint32_t,
    EXCLAVES_BOOT_STAGE_NONE = ~0u,
    EXCLAVES_BOOT_STAGE_2 = 0,
    EXCLAVES_BOOT_STAGE_EXCLAVEKIT = 100,

    /* The EXCLAVEKIT boot stage failed in some way. */
    EXCLAVES_BOOT_STAGE_FAILED = 200,
    );

OS_ENUM(exclaves_status, uint8_t,
    EXCLAVES_STATUS_NOT_STARTED = 0x00, /* Obsolete. Never used. */
    EXCLAVES_STATUS_AVAILABLE = 0x01,
    EXCLAVES_STATUS_FAILED = 0xFE,      /* Obsolete. Never used. */
    EXCLAVES_STATUS_NOT_SUPPORTED = 0xFF,
    );

#define MAX_CONCLAVE_RESOURCE_NUM 50


/*!
 * @function exclaves_endpoint_call
 *
 * @abstract
 * Perform RPC to an exclaves endpoint via per-thread exclaves IPC buffer.
 *
 * @param port
 * Reserved, must be IPC_PORT_NULL for now.
 *
 * @param endpoint_id
 * Identifier of exclaves endpoint to send RPC to.
 *
 * @param tag
 * In-out parameter for exclaves IPC tag.
 *
 * @param error
 * Out parameter for exclaves IPC error.
 *
 * @result
 * KERN_SUCCESS or mach error code.
 */
kern_return_t
exclaves_endpoint_call(ipc_port_t port, exclaves_id_t endpoint_id,
    exclaves_tag_t *tag, exclaves_error_t *error);

/*!
 * @function exclaves_allocate_ipc_buffer
 *
 * @abstract
 * If necessary, allocate per-thread exclaves IPC buffer.
 *
 * @param ipc_buffer
 * Out parameter filled in with address of IPC buffer. Can be NULL.
 *
 * @result
 * KERN_SUCCESS or mach error code.
 */
kern_return_t
exclaves_allocate_ipc_buffer(void **ipc_buffer);

/*!
 * @function exclaves_free_ipc_buffer
 *
 * @abstract
 * If necessary, free per-thread exclaves IPC buffer.
 *
 * @result
 * KERN_SUCCESS or mach error code.
 */
kern_return_t
exclaves_free_ipc_buffer(void);

/*!
 * @function exclaves_get_ipc_buffer
 *
 * @abstract
 * Return per-thread exclaves IPC buffer.
 *
 * @result
 * If allocated, pointer to per-thread exclaves IPC buffer, NULL otherwise.
 */
OS_CONST
void*
exclaves_get_ipc_buffer(void);

/* For use by Tightbeam kernel runtime only */

typedef uint64_t exclaves_badge_t;

/*!
 * @typedef exclaves_upcall_handler_t
 *
 * @abstract
 * RPC message handler for upcalls from exclaves via per-thread exclaves IPC
 * buffer.
 *
 * @param context
 * Opaque context pointer specified at handler registration.
 *
 * @param tag
 * In-out parameter for exclaves IPC tag.
 *
 * @param badge
 * Badge value identifying upcall RPC message.
 *
 * @result
 * KERN_SUCCESS or mach error code.
 */
typedef kern_return_t
(*exclaves_upcall_handler_t)(void *context, exclaves_tag_t *tag,
    exclaves_badge_t badge);

/*!
 * @function exclaves_register_upcall_handler
 *
 * @abstract
 * One-time registration of exclaves upcall RPC handler for specified upcall ID.
 * Must be called during Exclaves boot sequence, will assert otherwise.
 *
 * @param upcall_id
 * Identifier of upcall to configure.
 *
 * @param upcall_context
 * Opaque context pointer to pass to upcall RPC handler.
 *
 * @param upcall_handler
 * Pointer to upcall RPC handler.
 *
 * @result
 * KERN_SUCCESS or mach error code.
 */
kern_return_t
exclaves_register_upcall_handler(exclaves_id_t upcall_id, void *upcall_context,
    exclaves_upcall_handler_t upcall_handler);

struct XrtHosted_Callbacks;

/*!
 * @function xrt_hosted_register_callbacks
 *
 * @abstract
 * Exclaves XRT hosted kext interface.
 *
 * @param callbacks
 * Pointer to callback function table.
 */
void
exclaves_register_xrt_hosted_callbacks(struct XrtHosted_Callbacks *callbacks);

/*!
 * @enum exclaves_sensor_type_t
 *
 * @brief
 * Identifier for an exclaves sensor
 */
OS_ENUM(exclaves_sensor_type, uint32_t,
    EXCLAVES_SENSOR_CAM = 1,
    EXCLAVES_SENSOR_MIC = 2,
    EXCLAVES_SENSOR_CAM_ALT_FACEID = 3,
    /* update max if more sensors added */
    EXCLAVES_SENSOR_MAX = 3,
    );

/*!
 * @function exclaves_sensor_start
 *
 * @abstract
 * Start accessing a sensor and cause any indicators to display.
 *
 * If multiple clients start the same sensor, the sensor will only
 * actually start on the first client.
 *
 * @param sensor_type
 * type of sensor to operate on.
 *
 * @param flags to pass to the implementation. Must be 0 for now.
 *
 * @param sensor_status
 * Out parameter filled with the sensor status.
 *
 * @result
 * KERN_SUCCESS or mach system call error code.
 */
kern_return_t
exclaves_sensor_start(exclaves_sensor_type_t sensor_type, uint64_t flags,
    exclaves_sensor_status_t *sensor_status);

/*!
 * @function exclaves_sensor_stop
 *
 * @abstract
 * Stop accessing a sensor and cause any indicators to stop displaying access.
 *
 * If multiple clients are accessing the sensor, sensor access will
 * continue to display until all clients have called this function.
 *
 * @param sensor_type
 * type of sensor to operate on.
 *
 * @param flags to pass to the implementation. Must be 0 for now.
 *
 * @param sensor_status
 * Out parameter filled with the sensor status.
 *
 * @result
 * KERN_SUCCESS or mach system call error code.
 */
kern_return_t
exclaves_sensor_stop(exclaves_sensor_type_t sensor_type, uint64_t flags,
    exclaves_sensor_status_t *sensor_status);
/*!
 * @function exclaves_sensor_status
 *
 * @abstract
 * Get the status of access to a sensor
 *
 * @param sensor_type
 * type of sensor to operate on.
 *
 * @param sensor_status
 * Out parameter filled with the sensor status.
 *
 * @param flags to pass to the implementation. Must be 0 for now.
 *
 * @result
 * KERN_SUCCESS or mach system call error code.
 */
kern_return_t
exclaves_sensor_status(exclaves_sensor_type_t sensor_type, uint64_t flags,
    exclaves_sensor_status_t *sensor_status);

/*!
 * @function exclaves_display_healthcheck_rate
 *
 * @abstract
 * Update the rate of the display healthcheck based on the specified
 * display update rate
 *
 * @param ns
 * The rate in nanoseconds.
 * Note: This value may be be rounded to the nearest rate supported and not used
 * as-is.
 *
 * @result
 * KERN_SUCCESS or mach system call error code.
 */
kern_return_t
exclaves_display_healthcheck_rate(uint64_t ns);



/* -------------------------------------------------------------------------- */

/* Private interface between Libsyscall and xnu */

OS_ENUM(exclaves_ctl_op, uint8_t,
    EXCLAVES_CTL_OP_ENDPOINT_CALL = 1,
    EXCLAVES_CTL_OP_NAMED_BUFFER_CREATE = 2,
    EXCLAVES_CTL_OP_NAMED_BUFFER_COPYIN = 3,
    EXCLAVES_CTL_OP_NAMED_BUFFER_COPYOUT = 4,
    EXCLAVES_CTL_OP_BOOT = 5,
    EXCLAVES_CTL_OP_LAUNCH_CONCLAVE = 6,
    EXCLAVES_CTL_OP_LOOKUP_SERVICES = 7,
    EXCLAVES_CTL_OP_AUDIO_BUFFER_CREATE = 8,
    EXCLAVES_CTL_OP_AUDIO_BUFFER_COPYOUT = 9,
    EXCLAVES_CTL_OP_SENSOR_CREATE = 10,
    EXCLAVES_CTL_OP_SENSOR_START = 11,
    EXCLAVES_CTL_OP_SENSOR_STOP = 12,
    EXCLAVES_CTL_OP_SENSOR_STATUS = 13,
    EXCLAVES_CTL_OP_NOTIFICATION_RESOURCE_LOOKUP = 14,
    EXCLAVES_CTL_OP_LAST,
    );
#define EXCLAVES_CTL_FLAGS_MASK (0xfffffful)
#define EXCLAVES_CTL_OP_AND_FLAGS(op, flags) \
	((uint32_t)EXCLAVES_CTL_OP_##op << 24 | \
	((uint32_t)(flags) & EXCLAVES_CTL_FLAGS_MASK))
#define EXCLAVES_CTL_OP(op_and_flags) \
	((uint8_t)((op_and_flags) >> 24))
#define EXCLAVES_CTL_FLAGS(op_and_flags) \
	((uint32_t)(op_and_flags) & EXCLAVES_CTL_FLAGS_MASK)

/*!
 * @struct exclaves_resource_user
 *
 * @brief
 * User representation of exclave resource
 */
typedef struct exclaves_resource_user {
	char                  r_name[MAXCONCLAVENAME];
	uint64_t              r_type;
	exclaves_id_t         r_id;
	mach_port_name_t      r_port;
} exclaves_resouce_user_t;


/* -------------------------------------------------------------------------- */

/* Sysctl interface */


/*!
 * @function exclaves_get_status
 *
 * @abstract
 * Return the current running status of exclaves. This function will block until
 * exclaves has booted, failed to boot, or are known to be not available.
 *
 * @result
 * The status of exclaves.
 */
exclaves_status_t
exclaves_get_status(void);



__END_DECLS


#endif /* _MACH_EXCLAVES_H */
