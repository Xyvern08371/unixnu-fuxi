/* SPDX-License-Identifier: MIT */
/* C ABI of the bridge's Metal objects (NativeMetalObjects.rs): the metal2vulkan runtime's device, resources, states, queues, command buffers
 * and encoders as opaque handles, for the Objective-C frontend (NativeBridgeMetalFrontend.mm). Enumerations and option words are Metal's raw
 * values. A call that fails returns 0/NULL and leaves its reason in nmb_last_error() (per thread). Every handle is released once with its
 * release call; an encoder is released by its end call (or by nmb_encoder_discard when it is never ended). */
#ifndef NATIVE_METAL_OBJECTS_H
#define NATIVE_METAL_OBJECTS_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct NmbDevice NmbDevice;
typedef struct NmbBuffer NmbBuffer;
typedef struct NmbTexture NmbTexture;
typedef struct NmbLibrary NmbLibrary;
typedef struct NmbFunction NmbFunction;
typedef struct NmbComputePipeline NmbComputePipeline;
typedef struct NmbRenderPipeline NmbRenderPipeline;
typedef struct NmbSampler NmbSampler;
typedef struct NmbDepthStencil NmbDepthStencil;
typedef struct NmbQueue NmbQueue;
typedef struct NmbCommandBuffer NmbCommandBuffer;
typedef struct NmbEncoder NmbEncoder;
typedef struct NmbEvent NmbEvent;
typedef struct NmbFence NmbFence;

const char *nmb_last_error(void);
/* The bridge's embedded AIR fixtures: the runtime's own runtime_examples and kernel_function_constant_gate_fold. */
const void *nmb_fixture_air(size_t *length);
const void *nmb_function_constant_air(size_t *length);

/* loader: a library exporting vkGetInstanceProcAddr (Turnip on the tablet). cache: a writable directory for translated shaders. */
NmbDevice *nmb_device_open(const char *loader, const char *cache);
void nmb_device_release(NmbDevice *);
size_t nmb_device_name(const NmbDevice *, char *out, size_t size);
uint64_t nmb_device_max_buffer_length(const NmbDevice *);

NmbBuffer *nmb_buffer_new(NmbDevice *, uint64_t length, uint64_t options, const void *bytes /* NULL: zeroed */);
/* Wraps page-aligned memory the caller keeps mapped until the buffer is released (an IOSurface's base, host pages). */
NmbBuffer *nmb_buffer_new_no_copy(NmbDevice *, void *pointer, uint64_t length, uint64_t options);
void nmb_buffer_release(NmbBuffer *);
void *nmb_buffer_contents(const NmbBuffer *);
uint64_t nmb_buffer_length(const NmbBuffer *);
uint64_t nmb_buffer_gpu_address(const NmbBuffer *);

struct NmbTextureDescriptor {
    uint64_t type, format, width, height, depth, levels, samples, array_length, usage, options;
};
NmbTexture *nmb_texture_new(NmbDevice *, const struct NmbTextureDescriptor *);
/* A linear texture over a buffer's bytes; iosurface marks the buffer as standing for a surface without planes (Metal's IOSurface rules). */
NmbTexture *nmb_texture_new_on_buffer(NmbBuffer *, const struct NmbTextureDescriptor *, uint64_t offset, uint64_t bytes_per_row, bool iosurface);
void nmb_texture_release(NmbTexture *);
void nmb_texture_describe(const NmbTexture *, struct NmbTextureDescriptor *out);
bool nmb_texture_replace(NmbTexture *, const uint64_t region[6], uint64_t level, uint64_t slice, const void *bytes, uint64_t bytes_per_row,
                         uint64_t bytes_per_image, uint64_t length);
bool nmb_texture_get_bytes(const NmbTexture *, void *bytes, uint64_t bytes_per_row, uint64_t bytes_per_image, uint64_t length,
                           const uint64_t region[6], uint64_t level, uint64_t slice);

/* A metallib (a universal one gives its AIR64 slice), or with air set bare AIR bitcode. */
NmbLibrary *nmb_library_new(NmbDevice *, const void *bytes, size_t length, bool air);
void nmb_library_release(NmbLibrary *);
uint32_t nmb_library_function_count(const NmbLibrary *);
size_t nmb_library_function_name(const NmbLibrary *, uint32_t index, char *out, size_t size);
NmbFunction *nmb_function_new(NmbLibrary *, const char *name);
/* A function specialized with constant values (newFunctionWithName:constantValues:error:): type is Metal's MTLDataType, name is null for an
 * indexed value; bytes holds the value's bytes. */
struct NmbConstant {uint64_t type, index; const char *name; const void *bytes; uint64_t length;};
NmbFunction *nmb_function_new_specialized(NmbLibrary *, const char *name, const struct NmbConstant *constants, uint32_t count);
void nmb_function_release(NmbFunction *);
/* Metal's MTLFunctionType (1 vertex, 2 fragment, 3 kernel, ...). */
uint64_t nmb_function_type(const NmbFunction *);

NmbComputePipeline *nmb_compute_pipeline_new(NmbDevice *, NmbFunction *);
void nmb_compute_pipeline_release(NmbComputePipeline *);
uint64_t nmb_compute_pipeline_max_threads(const NmbComputePipeline *);
uint64_t nmb_compute_pipeline_execution_width(const NmbComputePipeline *);

struct NmbColorAttachment {
    uint64_t format, write_mask, blending, source_rgb, destination_rgb, rgb_operation, source_alpha, destination_alpha, alpha_operation;
};
struct NmbVertexAttribute {uint64_t format, offset, buffer;};
struct NmbVertexLayout {uint64_t stride, step_function, step_rate;};
struct NmbRenderPipelineDescriptor {
    NmbFunction *vertex, *fragment;
    struct NmbColorAttachment colors[8];
    uint64_t depth_format, stencil_format, samples, topology, rasterization;
    uint64_t vertex_inputs; /* 0: no vertex descriptor */
    struct NmbVertexAttribute attributes[31];
    struct NmbVertexLayout layouts[31];
};
NmbRenderPipeline *nmb_render_pipeline_new(NmbDevice *, const struct NmbRenderPipelineDescriptor *);
void nmb_render_pipeline_release(NmbRenderPipeline *);

struct NmbSamplerDescriptor {
    uint64_t min_filter, mag_filter, mip_filter, s_address, t_address, r_address, border_color, normalized, max_anisotropy, compare, lod_average;
    float lod_min, lod_max;
};
NmbSampler *nmb_sampler_new(NmbDevice *, const struct NmbSamplerDescriptor *);
void nmb_sampler_release(NmbSampler *);

struct NmbStencil {uint64_t compare, failure, depth_failure, pass, read_mask, write_mask;};
struct NmbDepthStencilDescriptor {uint64_t compare, write; struct NmbStencil front, back;};
NmbDepthStencil *nmb_depth_stencil_new(NmbDevice *, const struct NmbDepthStencilDescriptor *);
void nmb_depth_stencil_release(NmbDepthStencil *);

NmbQueue *nmb_queue_new(NmbDevice *);
void nmb_queue_release(NmbQueue *);
NmbCommandBuffer *nmb_command_buffer_new(NmbQueue *);
void nmb_command_buffer_release(NmbCommandBuffer *);
/* The handler runs once, on a runtime thread, after the command buffer completed or failed. */
bool nmb_command_buffer_on_completed(NmbCommandBuffer *, void (*handler)(void *context), void *context);
bool nmb_command_buffer_commit(NmbCommandBuffer *);
/* 0 completed in time, 1 timed out (timeout_ms 0 waits without a bound). */
int nmb_command_buffer_wait(NmbCommandBuffer *, uint64_t timeout_ms);
/* Metal's MTLCommandBufferStatus (0 not enqueued .. 4 completed, 5 error). */
uint64_t nmb_command_buffer_status(const NmbCommandBuffer *);
size_t nmb_command_buffer_error(const NmbCommandBuffer *, char *out, size_t size);
double nmb_command_buffer_gpu_time(const NmbCommandBuffer *, bool end);

/* Events: an MTLEvent (shared false) or an MTLSharedEvent within this process. */
NmbEvent *nmb_event_new(NmbDevice *, bool shared);
void nmb_event_release(NmbEvent *);
uint64_t nmb_shared_event_value(const NmbEvent *);
bool nmb_shared_event_set_value(NmbEvent *, uint64_t value);
/* true once the value is reached within timeout_ms */
bool nmb_shared_event_wait(NmbEvent *, uint64_t value, uint64_t timeout_ms);
/* handler(context, value) runs once on the bridge's listener thread when the value is reached (at once if it already is). */
bool nmb_shared_event_notify(NmbEvent *, uint64_t value, void (*handler)(void *context, uint64_t value), void *context);
bool nmb_command_buffer_signal_event(NmbCommandBuffer *, NmbEvent *, uint64_t value);
bool nmb_command_buffer_wait_event(NmbCommandBuffer *, NmbEvent *, uint64_t value);
NmbFence *nmb_fence_new(NmbDevice *);
void nmb_fence_release(NmbFence *);
/* stages: Metal's MTLRenderStages for a render encoder, ignored otherwise */
bool nmb_encoder_update_fence(NmbEncoder *, NmbFence *, uint64_t stages);
bool nmb_encoder_wait_fence(NmbEncoder *, NmbFence *, uint64_t stages);

NmbEncoder *nmb_compute_encoder_new(NmbCommandBuffer *);
NmbEncoder *nmb_blit_encoder_new(NmbCommandBuffer *);
struct NmbPassAttachment {
    NmbTexture *texture;
    uint64_t level, slice, depth_plane, load, store;
    double clear[4]; /* color, or clear[0] depth / stencil */
};
struct NmbRenderPassDescriptor {
    struct NmbPassAttachment colors[8], depth, stencil;
    uint64_t width, height, array_length, samples;
};
NmbEncoder *nmb_render_encoder_new(NmbCommandBuffer *, const struct NmbRenderPassDescriptor *);
bool nmb_encoder_end(NmbEncoder *);
void nmb_encoder_discard(NmbEncoder *);

/* stage: 0 compute, 1 vertex, 2 fragment */
bool nmb_encoder_set_buffer(NmbEncoder *, uint32_t stage, NmbBuffer *, uint64_t offset, uint32_t index);
bool nmb_encoder_set_buffer_offset(NmbEncoder *, uint32_t stage, uint64_t offset, uint32_t index);
bool nmb_encoder_set_bytes(NmbEncoder *, uint32_t stage, const void *bytes, size_t length, uint32_t index);
bool nmb_encoder_set_texture(NmbEncoder *, uint32_t stage, NmbTexture *, uint32_t index);
bool nmb_encoder_set_sampler(NmbEncoder *, uint32_t stage, NmbSampler *, uint32_t index);

bool nmb_compute_set_pipeline(NmbEncoder *, NmbComputePipeline *);
bool nmb_compute_set_threadgroup_memory(NmbEncoder *, uint32_t length, uint32_t index);
bool nmb_compute_dispatch(NmbEncoder *, const uint64_t size[3], const uint64_t per_group[3], bool threads);

bool nmb_render_set_pipeline(NmbEncoder *, NmbRenderPipeline *);
bool nmb_render_set_depth_stencil(NmbEncoder *, NmbDepthStencil *);
bool nmb_render_set_viewport(NmbEncoder *, const double viewport[6]);
bool nmb_render_set_scissor(NmbEncoder *, const uint64_t rect[4]);
bool nmb_render_set_raster(NmbEncoder *, uint64_t cull_mode, uint64_t winding, uint64_t fill_mode);
bool nmb_render_set_stencil_reference(NmbEncoder *, uint32_t front, uint32_t back);
bool nmb_render_set_blend_color(NmbEncoder *, const float color[4]);
bool nmb_render_draw(NmbEncoder *, uint64_t primitive, uint32_t start, uint32_t count, uint32_t instances, uint32_t base_instance);
bool nmb_render_draw_indexed(NmbEncoder *, uint64_t primitive, uint32_t count, uint64_t index_type, NmbBuffer *indices, uint64_t offset,
                             uint32_t instances, int32_t base_vertex, uint32_t base_instance);

bool nmb_blit_copy_buffer(NmbEncoder *, NmbBuffer *source, uint64_t source_offset, NmbBuffer *destination, uint64_t destination_offset,
                          uint64_t size);
bool nmb_blit_fill_buffer(NmbEncoder *, NmbBuffer *, uint64_t start, uint64_t end, uint8_t value);
/* origins and sizes are x,y,z / width,height,depth */
bool nmb_blit_copy_texture(NmbEncoder *, NmbTexture *source, uint64_t source_slice, uint64_t source_level, const uint64_t source_origin[3],
                           const uint64_t size[3], NmbTexture *destination, uint64_t destination_slice, uint64_t destination_level,
                           const uint64_t destination_origin[3]);
bool nmb_blit_buffer_to_texture(NmbEncoder *, NmbBuffer *source, uint64_t offset, uint64_t bytes_per_row, uint64_t bytes_per_image,
                                const uint64_t size[3], NmbTexture *destination, uint64_t slice, uint64_t level, const uint64_t origin[3]);
bool nmb_blit_texture_to_buffer(NmbEncoder *, NmbTexture *source, uint64_t slice, uint64_t level, const uint64_t origin[3],
                                const uint64_t size[3], NmbBuffer *destination, uint64_t offset, uint64_t bytes_per_row,
                                uint64_t bytes_per_image);
bool nmb_blit_generate_mipmaps(NmbEncoder *, NmbTexture *);
#ifdef __cplusplus
}
#endif
#endif
