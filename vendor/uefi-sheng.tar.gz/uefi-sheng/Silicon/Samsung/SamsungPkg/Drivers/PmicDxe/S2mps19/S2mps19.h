/**
  Copyright@ Samsung Electronics Co. LTD

  This software is proprietary of Samsung Electronics.
  No part of this software, either material or conceptual may be copied or distributed, transmitted,
  transcribed, stored in a retrieval system or translated into any human or computer language in any form by any means,
  electronic, mechanical, manual or otherwise, or disclosed
  to third parties without the express written permission of Samsung Electronics.
**/

#ifndef _S2MPS_19_H_
#define _S2MPS_19_H_

#include <Device/Pmic.h>

//
// Slave Addresses
//
#define S2MPS19_PM_ADDR            0x01
#define S2MPS19_RTC_ADDR           0x02

//
// PM Register Addresses
//
#define S2MPS19_PM_INT1            0x00
#define S2MPS19_PM_INT2            0x01
#define S2MPS19_PM_INT3            0x02
#define S2MPS19_PM_INT4            0x03
#define S2MPS19_PM_INT5            0x04
#define S2MPS19_PM_PWRONSRC        0x10
#define S2MPS19_PM_OFFSRC          0x11
#define S2MPS19_PM_RTC_BUF         0x13
#define S2MPS19_PM_CTRL1           0x14
#define S2MPS19_PM_CTRL3           0x16
#define S2MPS19_PM_ETC_OTP         0x18
#define S2MPS19_PM_LDOM_CTRL(x)    (0x45 + x)

//
// RTC Register Addresses
//
#define S2MPS19_RTC_WTSR_SMPL      0x01
#define S2MPS19_RTC_UPDATE         0x02
#define S2MPS19_RTC_CAP_SEL        0x03
#define S2MPS19_RTC_MSEC           0x04
#define S2MPS19_RTC_SEC            0x05
#define S2MPS19_RTC_MIN            0x06
#define S2MPS19_RTC_HOUR           0x07
#define S2MPS19_RTC_WEEK           0x08
#define S2MPS19_RTC_DAY            0x09
#define S2MPS19_RTC_MON            0x0A
#define S2MPS19_RTC_YEAR           0x0B

//
// WTSR & SMPL Register Bits
//
#define S2MPS19_RTC_WTSR_SET       BIT6
#define S2MPS19_RTC_SMPL_SET      (BIT7 | BIT8)

//
// Regulator Limits
//
#define MAX_S2MPS19_LDO_COUNT      29

//
// LDO Voltage Selection
//
// The Control Register carries the Enable State in its Top two Bits and the
// Voltage Selection in the Low six. Each Regulator belongs to one of five
// Groups, which decide the Lowest Voltage it can Produce and the Size of a
// Step. The Groups are taken from the Regulator Descriptor Table of the Vendor
// Kernel, drivers/regulator/s2mps19_regulator.c.
//
#define S2MPS19_LDO_VSEL_MASK      0x3F
#define S2MPS19_LDO_GROUP_COUNT    5

#define S2MPS19_LDO_GROUPS { \
  3, 2, 3, 1, 5, 5, 5, 5, 3, 3, 1, 2, 2, 2, 2,  \
  2, 1, 3, 1, 2, 1, 1, 3, 2, 1, 2, 2, 1, 2      \
}

#define S2MPS19_LDO_GROUP_MIN_UV   { 700000, 1800000, 700000, 400000, 300000 }
#define S2MPS19_LDO_GROUP_STEP_UV  {  25000,   25000,  12500,  12500,  25000 }

//
// LDO Regulator Modes
//
#define S2MPS19_OUTPUT_ON_TCXO     BIT6
#define S2MPS19_OUTPUT_ON_NORMAL  (BIT6 | BIT7)

#endif /* _S2MPS_19_H_ */
